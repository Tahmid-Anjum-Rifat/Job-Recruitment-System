package com.jobportal.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "premium_features")
public class PremiumFeature {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "feature_id")
    private int featureId;

    @ManyToOne
    @JoinColumn(name = "seeker_id")
    private JobSeeker seeker;

    @Column(name = "feature_type")
    private String featureType;
    @Column(name = "payment_status")
    private String paymentStatus;
    @Column(name = "payment_amount")
    private BigDecimal paymentAmount;

    // Getters and Setters...
}