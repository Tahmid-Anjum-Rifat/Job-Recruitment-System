package com.jobportal.model;

import jakarta.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "job")
public class Job {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "job_id")
    private int jobId;

    private String title;
    private int category_id; // Keeping simple for now, or map to Category Entity
    private String skills;
    private String experience;
    @Column(name = "salary_range")
    private String salaryRange;
    private Date deadline;
    private int vacancy;
    @Column(name = "posted_date")
    private Date postedDate;
    private String location;
    private String platform;
    private String requirement;

    @ManyToOne
    @JoinColumn(name = "company_id")
    private Company company;

    // Getters and Setters
    public int getJobId() { return jobId; }
    public void setJobId(int jobId) { this.jobId = jobId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public Company getCompany() { return company; }
    public void setCompany(Company company) { this.company = company; }
    // ... add remaining getters/setters ...
    public void setPostedDate(Date valueOf) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setPostedDate'");
    }
}