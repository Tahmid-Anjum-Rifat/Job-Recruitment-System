package com.jobportal.model;

import jakarta.persistence.*;

@Entity
@Table(name = "admin")
public class Admin extends User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "admin_id") // <--- THIS FIXES YOUR ERROR
    private int id;

    // Getter and Setter
    @Override
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
}