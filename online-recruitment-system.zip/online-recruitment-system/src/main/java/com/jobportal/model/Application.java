package com.jobportal.model;

import jakarta.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "application")
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "application_id")
    private int applicationId;

    @ManyToOne
    @JoinColumn(name = "seeker_id")
    private JobSeeker seeker;

    @ManyToOne
    @JoinColumn(name = "job_id")
    private Job job;

    private String resume;
    private String status; // "Pending", "Accepted", "Rejected"
    @Column(name = "application_date")
    private Date applicationDate;

    // Getters & Setters
    public int getApplicationId() { return applicationId; }
    public void setApplicationId(int id) { this.applicationId = id; }
    public JobSeeker getSeeker() { return seeker; }
    public void setSeeker(JobSeeker seeker) { this.seeker = seeker; }
    public Job getJob() { return job; }
    public void setJob(Job job) { this.job = job; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getResume() { return resume; }
    public void setResume(String resume) { this.resume = resume; }
    public Date getApplicationDate() { return applicationDate; }
    public void setApplicationDate(Date date) { this.applicationDate = date; }
}