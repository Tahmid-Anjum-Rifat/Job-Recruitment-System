package com.jobportal.model;

import jakarta.persistence.*;

@Entity
@Table(name = "company")
public class Company extends User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "company_id") // <--- Maps to company_id
    private int id;

    private String location;
    private String website;
    private String detail;

    // Getters & Setters
    @Override
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getWebsite() { return website; }
    public void setWebsite(String website) { this.website = website; }
    public String getDetail() { return detail; }
    public void setDetail(String detail) { this.detail = detail; }
}