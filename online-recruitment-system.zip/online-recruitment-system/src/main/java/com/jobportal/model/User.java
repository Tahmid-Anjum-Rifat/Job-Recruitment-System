package com.jobportal.model;

import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class User {
    // REMOVED @Id and int id from here. 
    // We will put them in the child classes instead.

    protected String name;
    protected String email;
    protected String password;
    protected String phone;

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    // Abstract method to force children to implement getId
    public abstract int getId();
}