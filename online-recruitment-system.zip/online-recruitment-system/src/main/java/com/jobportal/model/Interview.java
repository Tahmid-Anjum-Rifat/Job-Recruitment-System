package com.jobportal.model;

import jakarta.persistence.*;
import java.sql.Date;
import java.sql.Time;

@Entity
@Table(name = "interview")
public class Interview {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "interview_id")
    private int interviewId;

    @OneToOne
    @JoinColumn(name = "application_id")
    private Application application;

    @ManyToOne
    @JoinColumn(name = "company_id")
    private Company company;

    @ManyToOne
    @JoinColumn(name = "seeker_id")
    private JobSeeker seeker;

    @Column(name = "interview_date")
    private Date interviewDate;
    @Column(name = "interview_time")
    private Time interviewTime;
    
    private String location;
    private String type;
    @Column(name = "meeting_link")
    private String meetingLink;
    private String notes;
    private String status;
    public void setStatus(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setStatus'");
    }

    // Getters and Setters...
}