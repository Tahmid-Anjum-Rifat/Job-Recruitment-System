package com.jobportal.model;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "company_review")
public class CompanyReview {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "review_id")
    private int reviewId;

    @ManyToOne
    @JoinColumn(name = "seeker_id")
    private JobSeeker seeker;

    @ManyToOne
    @JoinColumn(name = "company_id")
    private Company company;

    private int rating;
    @Column(name = "review_text")
    private String reviewText;
    @Column(name = "created_at")
    private Timestamp createdAt;

    // Getters and Setters...
}