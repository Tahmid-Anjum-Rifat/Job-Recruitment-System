package com.jobportal.model;

import jakarta.persistence.*;

@Entity
@Table(name = "jobseeker")
public class JobSeeker extends User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seeker_id") // <--- Maps to seeker_id
    private int id;

    private String address;
    private String experience;
    private String skills;

    // Getters & Setters
    @Override
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getExperience() { return experience; }
    public void setExperience(String experience) { this.experience = experience; }
    public String getSkills() { return skills; }
    public void setSkills(String skills) { this.skills = skills; }
}