package com.jobportal.model;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "notification")
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "notification_id")
    private int notificationId;

    @ManyToOne
    @JoinColumn(name = "seeker_id")
    private JobSeeker seeker;

    @Column(name = "company_name")
    private String companyName;
    @Column(name = "job_title")
    private String jobTitle;
    
    private String message;
    @Column(name = "is_read")
    private boolean isRead;
    @Column(name = "created_at")
    private Timestamp createdAt;

    // Getters and Setters...
}