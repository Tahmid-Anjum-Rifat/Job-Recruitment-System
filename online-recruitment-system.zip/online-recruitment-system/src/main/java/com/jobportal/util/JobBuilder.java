package com.jobportal.util;

public class JobBuilder {

}
