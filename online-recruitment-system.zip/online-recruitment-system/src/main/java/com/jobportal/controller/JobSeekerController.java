package com.jobportal.controller;

import com.jobportal.model.*;
import com.jobportal.repository.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/seeker")
public class JobSeekerController {

    @Autowired private JobRepository jobRepo;
    @Autowired private ApplicationRepository appRepo;
    @Autowired private NotificationRepository notifRepo;

    // === 1. DASHBOARD ===
    @GetMapping("/dashboard")
    public String dashboard(@RequestParam(required = false) String keyword, HttpSession session, Model model) {
        JobSeeker user = (JobSeeker) session.getAttribute("user");
        if (user == null) return "redirect:/";

        // Logic for Search Bar
        List<Job> jobs;
        if (keyword != null && !keyword.isEmpty()) {
            jobs = jobRepo.findByTitleContaining(keyword);
        } else {
            jobs = jobRepo.findAll();
        }
        
        model.addAttribute("jobs", jobs);
        // Flags for premium buttons (You can make this dynamic later)
        model.addAttribute("canReview", false); 
        model.addAttribute("canEditProfile", true);

        return "seeker-dashboard"; // Matches seeker-dashboard.html
    }

    // === 2. SHOW APPLY FORM ===
    @GetMapping("/apply/{jobId}")
    public String showApplyForm(@PathVariable int jobId, Model model, HttpSession session) {
        if (session.getAttribute("user") == null) return "redirect:/";

        Job job = jobRepo.findById(jobId).orElse(null);
        model.addAttribute("job", job);
        
        return "apply-job"; // Matches apply-job.html
    }

    // === 3. SUBMIT APPLICATION ===
    @PostMapping("/apply")
    public String handleApply(@RequestParam int jobId, @RequestParam String resume, HttpSession session) {
        JobSeeker user = (JobSeeker) session.getAttribute("user");
        Job job = jobRepo.findById(jobId).orElse(null);

        // Create new Application
        Application app = new Application();
        app.setSeeker(user);
        app.setJob(job);
        app.setResume(resume); // In a real app, this would be a file path
        app.setStatus("Pending");
        app.setApplicationDate(Date.valueOf(LocalDate.now()));

        appRepo.save(app);

        return "redirect:/seeker/dashboard?applied=true";
    }

    // === 4. MY APPLICATIONS ===
    @GetMapping("/my-applications")
    public String myApplications(HttpSession session, Model model) {
        JobSeeker user = (JobSeeker) session.getAttribute("user");
        if (user == null) return "redirect:/";

        List<Application> myApps = appRepo.findBySeekerId(user.getId());
        model.addAttribute("myApps", myApps);
        
        return "my-applications"; // Matches my-applications.html
    }

    // === 5. NOTIFICATIONS ===
    @GetMapping("/notifications")
    public String notifications(HttpSession session, Model model) {
        JobSeeker user = (JobSeeker) session.getAttribute("user");
        if (user == null) return "redirect:/";

        List<Notification> notifs = notifRepo.findBySeekerIdOrderByCreatedAtDesc(user.getId());
        model.addAttribute("notifications", notifs);
        
        return "notifications"; // Matches notifications.html
    }
}