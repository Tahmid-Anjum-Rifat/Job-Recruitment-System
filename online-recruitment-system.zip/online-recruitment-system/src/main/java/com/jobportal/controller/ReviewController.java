package com.jobportal.controller;

import com.jobportal.model.CompanyReview;
import com.jobportal.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ReviewController {
    @Autowired private ReviewService reviewService;

    @PostMapping("/review/add")
    public String addReview(CompanyReview review) {
        reviewService.addReview(review);
        return "redirect:/seeker/dashboard";
    }
}