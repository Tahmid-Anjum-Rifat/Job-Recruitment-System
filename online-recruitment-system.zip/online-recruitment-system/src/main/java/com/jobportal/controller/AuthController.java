package com.jobportal.controller;

import com.jobportal.model.Company;
import com.jobportal.model.JobSeeker;
import com.jobportal.model.User;
import com.jobportal.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {
    @Autowired private UserService userService;

    @GetMapping("/")
    public String showLogin() { return "login"; }

    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password, 
                        @RequestParam String role, HttpSession session, Model model) {
        User user = userService.login(email, password, role);
        if (user != null) {
            session.setAttribute("user", user);
            session.setAttribute("role", role);
            if (role.equals("Company")) return "redirect:/company/dashboard";
            if (role.equals("Job Seeker")) return "redirect:/seeker/dashboard";
            if (role.equals("Admin")) return "redirect:/admin/dashboard";
        }
        model.addAttribute("error", "Invalid Credentials");
        return "login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
    // === JOB SEEKER REGISTRATION ===
    @GetMapping("/register/seeker")
    public String showSeekerRegistration(Model model) {
        model.addAttribute("seeker", new JobSeeker());
        return "register-seeker";
    }

    @PostMapping("/register/seeker")
    public String registerSeeker(@ModelAttribute JobSeeker seeker) {
        // We set the role explicitly
        userService.registerUser("Job Seeker", seeker);
        return "redirect:/?success"; // Redirect to login with success message
    }

    // === COMPANY REGISTRATION ===
    @GetMapping("/register/company")
    public String showCompanyRegistration(Model model) {
        model.addAttribute("company", new Company());
        return "register-company";
    }

    @PostMapping("/register/company")
    public String registerCompany(@ModelAttribute Company company) {
        userService.registerUser("Company", company);
        return "redirect:/?success";
    }
}