package com.jobportal.controller;

import com.jobportal.model.Company;
import com.jobportal.service.ApplicationService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/applications")
public class ApplicationController {
    @Autowired private ApplicationService appService;

    @GetMapping("/view/{appId}")
    public String viewApplication(@PathVariable int appId, HttpSession session, Model model) {
        Company user = (Company) session.getAttribute("user");
        try {
            // PROXY PATTERN IN ACTION
            // This throws exception if user doesn't own the job
            var app = appService.getApplicationSecurely(appId, user.getId());
            model.addAttribute("app", app);
            return "view-application";
        } catch (IllegalAccessException e) {
            return "error/403";
        }
    }
}