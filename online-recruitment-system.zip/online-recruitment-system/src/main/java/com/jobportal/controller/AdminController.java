package com.jobportal.controller;

import com.jobportal.model.Admin;
import com.jobportal.repository.CompanyRepository;
import com.jobportal.repository.JobSeekerRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private CompanyRepository companyRepo;

    @Autowired
    private JobSeekerRepository seekerRepo;

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        // 1. Security Check: Is the user logged in AND an Admin?
        // Note: In the simplified Login logic, we stored the user object.
        // For Admin, you might need to check the role specifically.
        String role = (String) session.getAttribute("role");
        if (role == null || !role.equals("Admin")) {
            return "redirect:/"; // Kick them out if not Admin
        }

        // 2. Load Data for the Dashboard Table
        model.addAttribute("companies", companyRepo.findAll());
        model.addAttribute("seekers", seekerRepo.findAll());

        // 3. Return the HTML template name
        return "admin-dashboard"; 
    }

    // Delete Company Functionality
    @GetMapping("/delete/company/{id}")
    public String deleteCompany(@PathVariable int id, HttpSession session) {
        String role = (String) session.getAttribute("role");
        if (role != null && role.equals("Admin")) {
            companyRepo.deleteById(id);
        }
        return "redirect:/admin/dashboard";
    }

    // Delete Job Seeker Functionality
    @GetMapping("/delete/seeker/{id}")
    public String deleteSeeker(@PathVariable int id, HttpSession session) {
        String role = (String) session.getAttribute("role");
        if (role != null && role.equals("Admin")) {
            seekerRepo.deleteById(id);
        }
        return "redirect:/admin/dashboard";
    }
}