package com.jobportal.controller;

import com.jobportal.model.*;
import com.jobportal.repository.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/company")
public class CompanyController {

    @Autowired private JobRepository jobRepo;
    @Autowired private ApplicationRepository appRepo;

    // === 1. DASHBOARD ===
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        // Security Check
        Company company = (Company) session.getAttribute("user");
        if (company == null) return "redirect:/";

        // Load jobs posted by this specific company
        List<Job> myJobs = jobRepo.findByCompanyId(company.getId());
        model.addAttribute("myJobs", myJobs);
        return "company-dashboard"; // Matches company-dashboard.html
    }

    // === 2. POST JOB (Show Form) ===
    @GetMapping("/post-job")
    public String showPostJobForm(HttpSession session) {
        if (session.getAttribute("user") == null) return "redirect:/";
        return "post-job"; // Matches post-job.html
    }

    // === 3. POST JOB (Handle Data) ===
    @PostMapping("/post-job")
    public String handlePostJob(@ModelAttribute Job job, HttpSession session) {
        Company company = (Company) session.getAttribute("user");
        
        // Link the job to the logged-in company
        job.setCompany(company);
        job.setPostedDate(Date.valueOf(LocalDate.now())); // Set current date
        
        jobRepo.save(job);
        return "redirect:/company/dashboard";
    }

    // === 4. VIEW APPLICANTS FOR A JOB ===
    @GetMapping("/applications/view-job/{jobId}")
    public String viewApplicants(@PathVariable int jobId, Model model, HttpSession session) {
        // Fetch applications for this specific job
        List<Application> apps = appRepo.findByJobJobId(jobId);
        model.addAttribute("applications", apps);
        
        // We also send the Job Title to display it
        Job job = jobRepo.findById(jobId).orElse(null);
        model.addAttribute("jobTitle", job != null ? job.getTitle() : "Unknown Job");
        
        return "view-applications"; // Matches view-applications.html
    }

    // === 5. ACTIONS (Hire/Reject) ===
    @GetMapping("/hire/{appId}")
    public String hireCandidate(@PathVariable int appId) {
        Application app = appRepo.findById(appId).orElse(null);
        if (app != null) {
            app.setStatus("Hired");
            appRepo.save(app);
        }
        // Redirect back to the previous list (this is a simple redirect)
        return "redirect:/company/dashboard"; 
    }

    @GetMapping("/reject/{appId}")
    public String rejectCandidate(@PathVariable int appId) {
        Application app = appRepo.findById(appId).orElse(null);
        if (app != null) {
            app.setStatus("Rejected");
            appRepo.save(app);
        }
        return "redirect:/company/dashboard";
    }
}