package com.jobportal.repository;
import com.jobportal.model.PremiumFeature;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PremiumFeatureRepository extends JpaRepository<PremiumFeature, Integer> {
    boolean existsBySeekerIdAndFeatureType(int seekerId, String featureType);
}