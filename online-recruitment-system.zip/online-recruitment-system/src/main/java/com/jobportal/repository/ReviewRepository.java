package com.jobportal.repository;
import com.jobportal.model.CompanyReview;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReviewRepository extends JpaRepository<CompanyReview, Integer> {
    List<CompanyReview> findByCompanyIdOrderByCreatedAtDesc(int companyId);
}