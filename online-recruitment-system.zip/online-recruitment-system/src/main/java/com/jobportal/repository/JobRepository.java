package com.jobportal.repository;
import com.jobportal.model.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface JobRepository extends JpaRepository<Job, Integer> {
    List<Job> findByTitleContaining(String keyword);
    List<Job> findByCompanyId(int companyId); // Maps to getJobsByCompany
}