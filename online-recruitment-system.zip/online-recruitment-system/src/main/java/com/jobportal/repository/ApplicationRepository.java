package com.jobportal.repository;
import com.jobportal.model.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ApplicationRepository extends JpaRepository<Application, Integer> {
    List<Application> findBySeekerId(int seekerId);
    
    // For Company viewing applications for a specific job
    List<Application> findByJobJobId(int jobId);
    
    // For Company viewing ALL their applications
    List<Application> findByJobCompanyId(int companyId);
}