package com.jobportal.repository;
import com.jobportal.model.Interview;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InterviewRepository extends JpaRepository<Interview, Integer> {
    List<Interview> findByCompanyId(int companyId);
    List<Interview> findBySeekerId(int seekerId);
}