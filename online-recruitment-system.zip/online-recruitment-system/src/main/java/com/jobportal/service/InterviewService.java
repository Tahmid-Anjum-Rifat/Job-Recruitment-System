package com.jobportal.service;

import com.jobportal.model.Interview;
import com.jobportal.repository.InterviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InterviewService {
    @Autowired private InterviewRepository interviewRepo;

    public void scheduleInterview(Interview interview) {
        interview.setStatus("Scheduled");
        interviewRepo.save(interview);
    }
}