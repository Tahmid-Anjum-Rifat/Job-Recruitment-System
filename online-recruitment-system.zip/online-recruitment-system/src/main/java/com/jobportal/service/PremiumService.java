package com.jobportal.service;

import com.jobportal.repository.PremiumFeatureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PremiumService {
    @Autowired private PremiumFeatureRepository premiumRepo;

    public boolean canWriteReview(int seekerId) {
        return premiumRepo.existsBySeekerIdAndFeatureType(seekerId, "REVIEW_FEATURE");
    }

    public boolean canEditProfile(int seekerId) {
        return premiumRepo.existsBySeekerIdAndFeatureType(seekerId, "PROFILE_EDIT");
    }
}