package com.jobportal.service;

import com.jobportal.model.CompanyReview;
import com.jobportal.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ReviewService {
    @Autowired private ReviewRepository reviewRepo;

    public void addReview(CompanyReview review) {
        reviewRepo.save(review);
    }

    public List<CompanyReview> getReviewsForCompany(int companyId) {
        return reviewRepo.findByCompanyIdOrderByCreatedAtDesc(companyId);
    }
}