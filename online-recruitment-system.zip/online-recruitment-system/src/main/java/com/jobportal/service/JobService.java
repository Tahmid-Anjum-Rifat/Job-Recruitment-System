package com.jobportal.service;

import com.jobportal.model.Job;
import com.jobportal.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class JobService {
    @Autowired private JobRepository jobRepo;

    // BUILDER PATTERN USAGE: The controller passes the built object, service saves it
    public void postJob(Job job) {
        // You can add validation logic here (e.g., check if deadline is future)
        jobRepo.save(job);
    }

    public List<Job> searchJobs(String keyword) {
        if (keyword != null && !keyword.isEmpty()) {
            return jobRepo.findByTitleContaining(keyword);
        }
        return jobRepo.findAll();
    }
    
    public List<Job> getJobsByCompany(int companyId) {
        return jobRepo.findByCompanyId(companyId);
    }
}