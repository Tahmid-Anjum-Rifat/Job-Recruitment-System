package com.jobportal.service;

import com.jobportal.model.Notification;
import com.jobportal.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class NotificationService {
    @Autowired private NotificationRepository notifRepo;

    public List<Notification> getMyNotifications(int seekerId) {
        return notifRepo.findBySeekerIdOrderByCreatedAtDesc(seekerId);
    }
    
    public void createNotification(Notification notif) {
        notifRepo.save(notif);
    }
}