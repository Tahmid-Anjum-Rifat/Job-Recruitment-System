package com.jobportal.service;

import com.jobportal.model.*;
import com.jobportal.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired private JobSeekerRepository seekerRepo;
    @Autowired private CompanyRepository companyRepo;
    @Autowired private AdminRepository adminRepo;

    // FACTORY METHOD: Centralized user creation
    public void registerUser(String role, User user) {
        if (role.equalsIgnoreCase("Job Seeker")) {
            seekerRepo.save((JobSeeker) user);
        } else if (role.equalsIgnoreCase("Company")) {
            companyRepo.save((Company) user);
        } else if (role.equalsIgnoreCase("Admin")) {
            adminRepo.save((Admin) user);
        }
    }

    public User login(String email, String password, String role) {
        User user = null;
        if (role.equalsIgnoreCase("Job Seeker")) {
            user = seekerRepo.findByEmail(email);
        } else if (role.equalsIgnoreCase("Company")) {
            user = companyRepo.findByEmail(email);
        } else if (role.equalsIgnoreCase("Admin")) {
            user = adminRepo.findByEmail(email);
        }

        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}