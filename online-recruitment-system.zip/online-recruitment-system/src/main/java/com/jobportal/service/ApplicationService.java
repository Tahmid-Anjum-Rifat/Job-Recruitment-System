package com.jobportal.service;

import com.jobportal.model.Application;
import com.jobportal.repository.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ApplicationService {
    @Autowired private ApplicationRepository appRepo;

    public void apply(Application app) {
        app.setStatus("Pending");
        appRepo.save(app);
    }

    public List<Application> getMyApplications(int seekerId) {
        return appRepo.findBySeekerId(seekerId);
    }

    // PROXY PATTERN LOGIC: Secure Access Control
    public Application getApplicationSecurely(int applicationId, int requestingCompanyId) throws IllegalAccessException {
        Application app = appRepo.findById(applicationId).orElse(null);
        
        if (app == null) return null;

        // Security Check: Does this job belong to the requesting company?
        if (app.getJob().getCompany().getId() != requestingCompanyId) {
            throw new IllegalAccessException("ACCESS DENIED: You do not own this job posting.");
        }

        return app;
    }

    public List<Application> getCompanyApplications(int companyId) {
        return appRepo.findByJobCompanyId(companyId);
    }
}