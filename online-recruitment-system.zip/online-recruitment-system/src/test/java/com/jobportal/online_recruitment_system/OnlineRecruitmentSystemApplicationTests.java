package com.jobportal.online_recruitment_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineRecruitmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
