package onlinejobrecruitment;

import java.sql.*;

public class Admin extends User {

    public Admin(String name, String email, String password) {
        super(name, email, password);
    }

    // Constructor for Login
    public Admin(String email, String password) {
        super(null, email, password);
    }

    @Override
    public boolean register() {
        String sql = "INSERT INTO admin (name, email, password) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, password);
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    this.id = rs.getInt(1);
                }
                System.out.println("Admin registered successfully! ID: " + this.id);
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Admin Registration failed: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean login() {
        String sql = "SELECT admin_id, name FROM admin WHERE email = ? AND password = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                this.id = rs.getInt("admin_id");
                this.name = rs.getString("name");
                System.out.println("Admin Login successful! Welcome, " + name);
                return true;
            } else {
                System.out.println("Invalid Admin credentials.");
            }
        } catch (SQLException e) {
            System.out.println("Login error: " + e.getMessage());
        }
        return false;
    }

    // --- VIEW METHODS ---

    public void viewAllCompanies() {
        String sql = "SELECT company_id, name, email, location, phone FROM company";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            System.out.println("\n--- Registered Companies ---");
            System.out.printf("%-5s %-20s %-25s %-15s\n", "ID", "Name", "Email", "Location");
            System.out.println("----------------------------------------------------------------");
            
            while (rs.next()) {
                System.out.printf("%-5d %-20s %-25s %-15s\n", 
                    rs.getInt("company_id"), 
                    rs.getString("name"), 
                    rs.getString("email"), 
                    rs.getString("location"));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching companies: " + e.getMessage());
        }
    }

    public void viewAllJobSeekers() {
        String sql = "SELECT seeker_id, name, email, skills, experience FROM jobseeker";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            System.out.println("\n--- Registered Job Seekers ---");
            System.out.printf("%-5s %-20s %-25s %-20s\n", "ID", "Name", "Email", "Skills");
            System.out.println("----------------------------------------------------------------");
            
            while (rs.next()) {
                System.out.printf("%-5d %-20s %-25s %-20s\n", 
                    rs.getInt("seeker_id"), 
                    rs.getString("name"), 
                    rs.getString("email"), 
                    rs.getString("skills"));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching seekers: " + e.getMessage());
        }
    }

    // --- REGULATION METHODS (DELETE) ---

    public boolean deleteCompany(int companyId) {
    String sql = "DELETE FROM company WHERE company_id = ?";
    
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setInt(1, companyId);
        int affectedRows = pstmt.executeUpdate();
        
        if (affectedRows > 0) {
            System.out.println("Company and all related data deleted successfully!");
            return true;
        }
    } catch (SQLException e) {
        System.out.println("Error deleting company: " + e.getMessage());
    }
    return false;
}

    public boolean deleteJobSeeker(int seekerId) {
        // Delete Applications -> Seeker
        String deleteApps = "DELETE FROM application WHERE seeker_id = ?";
        String deleteSeeker = "DELETE FROM jobseeker WHERE seeker_id = ?";

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false); 

            try {
                // 1. Delete their applications
                try (PreparedStatement ps1 = conn.prepareStatement(deleteApps)) {
                    ps1.setInt(1, seekerId);
                    ps1.executeUpdate();
                }

                // 2. Delete the seeker
                try (PreparedStatement ps2 = conn.prepareStatement(deleteSeeker)) {
                    ps2.setInt(1, seekerId);
                    int rows = ps2.executeUpdate();
                    
                    if (rows > 0) {
                        conn.commit();
                        System.out.println("Job Seeker deleted successfully.");
                        return true;
                    }
                }
            } catch (SQLException e) {
                conn.rollback();
                System.out.println("Error deleting seeker: " + e.getMessage());
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}