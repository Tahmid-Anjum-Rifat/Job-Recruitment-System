/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinejobrecruitment;

import java.sql.*;
public class Company extends User{
 private String phone;
    private String location;
    private String website;
    private String detail;
    
    public Company(String name, String email, String password, String phone, 
                   String location, String website, String detail) {
        super(name, email, password);
        this.phone = phone;
        this.location = location;
        this.website = website;
        this.detail = detail;
    }
    
    public Company(String email, String password) {
        super(null, email, password);
    }
    
    @Override
    public boolean register() {
        String sql = "INSERT INTO company (name, email, password, phone, location, website, detail) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, password);
            pstmt.setString(4, phone);
            pstmt.setString(5, location);
            pstmt.setString(6, website);
            pstmt.setString(7, detail);
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    this.id = rs.getInt(1);
                }
                System.out.println("Company registered successfully! Company ID: " + this.id);
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Registration failed: " + e.getMessage());
        }
        return false;
    }
    
    @Override
    public boolean login() {
        String sql = "SELECT company_id, name, phone, location, website, detail FROM company WHERE email = ? AND password = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                this.id = rs.getInt("company_id");
                this.name = rs.getString("name");
                this.phone = rs.getString("phone");
                this.location = rs.getString("location");
                this.website = rs.getString("website");
                this.detail = rs.getString("detail");
                
                System.out.println("Login successful! Welcome, " + name);
                return true;
            } else {
                System.out.println("Login failed: Invalid credentials");
            }
        } catch (SQLException e) {
            System.out.println("Login failed: " + e.getMessage());
        }
        return false;
    }
    
    public boolean postJob(String title, int categoryId, String skills, String experience,
                          String salaryRange, Date deadline, int vacancy, String location,
                          String platform, String requirement) {
        String sql = "INSERT INTO job (company_id, category_id, title, skills, experience, " +
                     "salary_range, deadline, vacancy, posted_date, location, platform, requirement) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, this.id);
            pstmt.setInt(2, categoryId);
            pstmt.setString(3, title);
            pstmt.setString(4, skills);
            pstmt.setString(5, experience);
            pstmt.setString(6, salaryRange);
            pstmt.setDate(7, deadline);
            pstmt.setInt(8, vacancy);
            pstmt.setString(9, location);
            pstmt.setString(10, platform);
            pstmt.setString(11, requirement);
            
            pstmt.executeUpdate();
            System.out.println("Job posted successfully!");
            return true;
        } catch (SQLException e) {
            System.out.println("Failed to post job: " + e.getMessage());
        }
        return false;
    }
    
    // Getters
    public String getPhone() { return phone; }
    public String getLocation() { return location; }
    public String getWebsite() { return website; }
    public String getDetail() { return detail; } 
}
